Cleaning Schedule

Print at home or at a print shop. Two sizes are included: A4 and US Letter.
Print as many copies as you like for personal use. For best results print at 100% scale (no 'fit to page').
You can also use the PDF on a tablet with an annotation app such as GoodNotes or Notability.
