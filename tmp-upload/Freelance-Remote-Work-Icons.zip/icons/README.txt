48 line icons on a 24px grid, 1.75 stroke, round caps.
svg/ editable stroke (uses currentColor), png/ 64-256-512 navy, png-white/, png-teal/, eps/ per icon, sprite.svg for websites, all-icons-sheet.svg.
