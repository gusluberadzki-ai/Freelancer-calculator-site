12 grainy gradient backgrounds, 6000x4000 px JPG (24 MP).
Great for social posts, slides, website heroes, phone wallpapers and print.
