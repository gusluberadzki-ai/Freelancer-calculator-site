12 seamless patterns.
svg-tile/ vector tile (use as a pattern fill or repeat it), png-tile-1000/ raster tile, jpg-3600/ 3600x3600 ready-made swatches, eps/ 3x3 vector swatch.
In Canva / Photoshop / Procreate, repeat the tile edge to edge; it has no visible seam.
